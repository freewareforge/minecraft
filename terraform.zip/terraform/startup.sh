#!/bin/bash

# Navigate to the desired directory
cd /opt/minecraft

# Check for initialized file
if [ ! -f initialized ]; then

    echo "Initializing server, then running..."

    # Receive Minecraft username variable from Terraform user data
    USERNAME=$1

    # Download the Minecraft server jar
    wget --tries=5 --waitretry=10 --read-timeout=30 -O server.jar https://piston-data.mojang.com/v1/objects/8dd1a28015f51b1803213892b50b7b4fc76e594d/server.jar

    # Run the Minecraft server
    java -Xmx4096M -Xms1024M -jar server.jar nogui

    # Accept EULA after the server's first termination (which generates eula.txt)
    sed -i 's/eula=false/eula=true/g' eula.txt

    # Then, run the Minecraft server again
    tmux new-session -d -s minecraft 'java -Xmx4096M -Xms1024M -jar server.jar nogui'

    # Wait a bit, then issue Minecraft server console command to make user admin
    sleep 30
    tmux send-keys -t minecraft "op $USERNAME" Enter

    # Create initialized file
    touch initialized

    echo "Server initialized and running."

else

    # Directly run the server

    echo "Server previously initialized, running server now."

    tmux new-session -d -s minecraft 'java -Xmx4096M -Xms1024M -jar server.jar nogui'

    echo "Server running."

fi